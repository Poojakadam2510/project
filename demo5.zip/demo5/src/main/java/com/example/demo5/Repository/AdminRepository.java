package com.example.demo5.Repository;

import com.example.demo5.Model.Admindetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admindetails,Integer> {
}
