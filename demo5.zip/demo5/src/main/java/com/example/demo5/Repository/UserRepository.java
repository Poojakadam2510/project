package com.example.demo5.Repository;

import com.example.demo5.Model.Userdetails;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<Userdetails,Long> {
}
